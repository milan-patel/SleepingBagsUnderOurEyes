package com.example.please

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import com.github.windsekirun.naraeaudiorecorder.NaraeAudioRecorder
import java.io.File

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val audioRecorder = NaraeAudioRecorder()
        val destFile = File(Environment.getExternalStorageDirectory(), "/NaraeAudioRecorder/hello.wav")
        audioRecorder.create() {
            this.destFile = destFile
        }
        audioRecorder.checkPermission(this)
        setContentView(R.layout.activity_main)
    }

}
